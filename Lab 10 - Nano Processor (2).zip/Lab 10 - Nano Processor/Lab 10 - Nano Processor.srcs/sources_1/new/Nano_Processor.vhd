----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/15/2025 03:19:54 PM
-- Design Name: 
-- Module Name: Nano_Processor - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Nano_Processor is
    Port ( Clk : in STD_LOGIC;  
           Reset : in STD_LOGIC;
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC;
           Value : out STD_LOGIC_VECTOR (3 downto 0));
end Nano_Processor;

architecture Behavioral of Nano_Processor is

component Slow_Clk is
    Port ( clk_in : in STD_LOGIC;
           clk_out : out STD_LOGIC);
end component;

component Program_ROM is
    Port ( ROM_Sel : in STD_LOGIC_VECTOR (2 downto 0);
           Ins : out STD_LOGIC_VECTOR (11 downto 0));
end component;

component Program_Counter is
    Port ( Clk : in STD_LOGIC;
           PC_In : in STD_LOGIC_VECTOR (2 downto 0);
           Reset : in STD_LOGIC;
           PC_Out : out STD_LOGIC_VECTOR (2 downto 0));
end component;

component Ins_Decoder is
    Port ( Ins : in STD_LOGIC_VECTOR (11 downto 0);
           Jmp_Reg_Chk : in STD_LOGIC_VECTOR (3 downto 0);
           Load_Sel : out STD_LOGIC;
           Imd_Val : out STD_LOGIC_VECTOR (3 downto 0);
           Reg_En : out STD_LOGIC_VECTOR (2 downto 0);
           Reg_Sel_A : out STD_LOGIC_VECTOR (2 downto 0);
           Reg_Sel_B : out STD_LOGIC_VECTOR (2 downto 0);
           Add_Sub_Sel : out STD_LOGIC;
           Add_Sub_En : out STD_LOGIC;
           Jmp_Flg : out STD_LOGIC;
           Adrs_to_Jmp : out STD_LOGIC_VECTOR (2 downto 0));
end component;

component Mux_2_3 is
    Port ( I_0     : in  STD_LOGIC_VECTOR(2 downto 0);
           I_1     : in  STD_LOGIC_VECTOR(2 downto 0);
           Selector: in  STD_LOGIC;
           Q       : out STD_LOGIC_VECTOR(2 downto 0));
end component;

component Mux_2_4 is
    Port ( I_0 : in STD_LOGIC_VECTOR (3 downto 0);
           I_1 : in STD_LOGIC_VECTOR (3 downto 0);
           Selector : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component Mux_8_4 is
    Port ( I_0 : in STD_LOGIC_VECTOR (3 downto 0);
           I_1 : in STD_LOGIC_VECTOR (3 downto 0);
           I_2 : in STD_LOGIC_VECTOR (3 downto 0);
           I_3 : in STD_LOGIC_VECTOR (3 downto 0);
           I_4 : in STD_LOGIC_VECTOR (3 downto 0);
           I_5 : in STD_LOGIC_VECTOR (3 downto 0);
           I_6 : in STD_LOGIC_VECTOR (3 downto 0);
           I_7 : in STD_LOGIC_VECTOR (3 downto 0);
           Selector : in STD_LOGIC_VECTOR (2 downto 0);
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component Register_Bank is
    Port ( RB_En : in STD_LOGIC;     
           Clk : in STD_LOGIC;
           Reset : in STD_LOGIC;
           R_En : in STD_LOGIC_VECTOR (2 downto 0);
           input : in STD_LOGIC_VECTOR (3 downto 0);
           R_0 : out STD_LOGIC_VECTOR (3 downto 0);
           R_1 : out STD_LOGIC_VECTOR (3 downto 0);
           R_2 : out STD_LOGIC_VECTOR (3 downto 0);
           R_3 : out STD_LOGIC_VECTOR (3 downto 0);
           R_4 : out STD_LOGIC_VECTOR (3 downto 0);
           R_5 : out STD_LOGIC_VECTOR (3 downto 0);
           R_6 : out STD_LOGIC_VECTOR (3 downto 0);
           R_7 : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component Incrementer is
    Port ( A : in STD_LOGIC_VECTOR (2 downto 0);
           Q : out STD_LOGIC_VECTOR (2 downto 0));
end component;

component Adder_Subtractor is
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0);
           B : in STD_LOGIC_VECTOR (3 downto 0);
           M : in STD_LOGIC;
           En : in STD_LOGIC;
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC);
end component;

signal Clk_Out , Load_Sel , Jmp_Flg , Add_Sub_Sel, Add_Sub_En, Overflow_Out, Zero_Out : STD_LOGIC ;
signal PC_In , PC_Out , Reg_En , Reg_Sel_A , Reg_Sel_B , Adrs_to_Jmp , Adder_Out : STD_LOGIC_VECTOR (2 downto 0);
signal R0 , R1 , R2 , R3 , R4 , R5 , R6 , R7 , Imd_Val , Load_Sel_Out , Add_Sub_Out , Mux_A_Out , Mux_B_Out , Flags: STD_LOGIC_VECTOR (3 downto 0);
signal Ins_Dec_In : STD_LOGIC_VECTOR (11 downto 0);

begin

Slow_Clk_0 : Slow_Clk
port map(
    clk_in => Clk ,
    clk_out => Clk_Out );

Program_Counter_0 : Program_Counter
Port map(
    Reset => Reset,
    Clk => Clk_Out,
    PC_In => PC_In,
    PC_Out => PC_Out
    );

Muc_2_3_0 : Mux_2_3
port map(
    I_1 => Adrs_to_Jmp,
    I_0 => Adder_Out,
    Selector => Jmp_Flg,
    Q => PC_In
    );
        
Program_ROM_0 : Program_ROM
Port map(
    ROM_Sel => PC_Out,
    Ins => Ins_Dec_In
    );
    
Ins_Decoder_0 : Ins_Decoder
port map(
    Ins => Ins_Dec_In,
    Jmp_Reg_Chk => Mux_A_Out,
    Reg_En => Reg_En,
    Reg_Sel_A => Reg_Sel_A,
    Reg_Sel_B => Reg_Sel_B,
    Load_Sel => Load_Sel,
    Add_Sub_Sel => Add_Sub_Sel,
    Add_Sub_En => Add_Sub_En,
    Jmp_Flg => Jmp_Flg,
    Adrs_to_Jmp => Adrs_to_Jmp,
    Imd_Val => Imd_Val
    );
 
Register_Bank_0 : Register_Bank
port map(
    RB_En => '1',
    Clk => Clk_Out,
    R_En => Reg_En,
    Input => Load_Sel_Out,
    Reset => Reset,
    R_0 => R0,
    R_1 => R1,
    R_2 => R2,
    R_3 => R3,
    R_4 => R4,
    R_5 => R5,
    R_6 => R6,
    R_7 => R7   
    );

Load_Selector : Mux_2_4
port map(
    I_1 => Imd_Val,
    I_0 => Add_Sub_Out,
    Selector => Load_Sel,
    Q => Load_Sel_Out
    );

Mux_8_4_A : Mux_8_4
port map(
    I_0 => R0,
    I_1 => R1,
    I_2 => R2,
    I_3 => R3,
    I_4 => R4,
    I_5 => R5,
    I_6 => R6,
    I_7 => R7,
    Selector => Reg_Sel_A,
    Q => Mux_A_Out   
    );
    
Mux_8_4_B : Mux_8_4
port map(
    I_0 => R0,
    I_1 => R1,
    I_2 => R2,
    I_3 => R3,
    I_4 => R4,
    I_5 => R5,
    I_6 => R6,
    I_7 => R7,
    Selector => Reg_Sel_B,
    Q => Mux_B_Out   
    );
    
Add_Sub : Adder_Subtractor
port map(
    A => Mux_A_Out,  
    B => Mux_B_Out,
    M => Add_Sub_Sel,
    En => Add_Sub_En,
    S => Add_Sub_Out,
    Overflow => Overflow_Out,
    Zero => Zero_Out
    );

Incrementer_0 : Incrementer
port map(
    A => PC_Out,
    Q => Adder_Out
    );

Value <= R7 ;

process(Clk_Out)
begin
    if rising_edge(Clk_Out) then
        Overflow <= Overflow_Out;
        Zero <= Zero_Out;
    end if;
end process;


end Behavioral;