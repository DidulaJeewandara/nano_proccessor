----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/15/2025 02:54:39 PM
-- Design Name: 
-- Module Name: Adder_Subtractor - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Adder_Subtractor is
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0) ;
           B : in STD_LOGIC_VECTOR (3 downto 0) ;
           M : in STD_LOGIC ;
           En : in STD_LOGIC ;
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC);
end Adder_Subtractor;

architecture Behavioral of Adder_Subtractor is
    signal A_s, B_s : signed(3 downto 0);
    signal result   : signed(4 downto 0);  -- 1 extra bit for overflow
begin

    A_s <= signed(A);  -- Optimize using Maths
    B_s <= signed(B);

    process(A_s, B_s, M)
    begin
        if M = '0' then
            result <= resize(A_s, 5) + resize(B_s, 5);
        else
            result <= resize(A_s, 5) - resize(B_s, 5);
        end if;
    end process;

    S <= std_logic_vector(result(3 downto 0));
    
    Overflow <= result(4) xor result(3);  -- standard 2's complement overflow
    
    Zero <= '1' when result(3 downto 0) = "0000" and En = '1' else '0';

end Behavioral;