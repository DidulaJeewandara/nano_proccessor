----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/11/2025 08:01:02 PM
-- Design Name: 
-- Module Name: Ins_Decoder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Ins_Decoder is
    Port ( Ins : in STD_LOGIC_VECTOR (11 downto 0);
           Jmp_Reg_Chk : in STD_LOGIC_VECTOR (3 downto 0);
           Load_Sel : out STD_LOGIC;
           Imd_Val : out STD_LOGIC_VECTOR (3 downto 0);
           Reg_En : out STD_LOGIC_VECTOR (2 downto 0);
           Reg_Sel_A : out STD_LOGIC_VECTOR (2 downto 0);
           Reg_Sel_B : out STD_LOGIC_VECTOR (2 downto 0);
           Add_Sub_Sel : out STD_LOGIC;
           Add_Sub_En : out STD_LOGIC;
           Jmp_Flg : out STD_LOGIC;
           Adrs_to_Jmp : out STD_LOGIC_VECTOR (2 downto 0));
end Ins_Decoder;

architecture Behavioral of Ins_Decoder is

begin

process(Ins, Jmp_Reg_Chk)
begin
    -- Default values
    Load_Sel <= '0';
    Imd_Val <= (others => '0');  -- all bits = 0
    Reg_En <= Ins(9 downto 7);  -- for many cases
    Reg_Sel_A <= (others => '0');
    Reg_Sel_B <= (others => '0');
    Add_Sub_Sel <= '0';
    Add_Sub_En <= '0' ;
    Jmp_Flg <= '0';
    Adrs_to_Jmp <= Ins(2 downto 0);  -- always assigned

    case Ins(11 downto 10) is
    
        when "10" =>  -- MOVI
            Load_Sel <= '1';
            Imd_Val <= Ins(3 downto 0);
            
        when "00" =>  -- ADD
            Reg_Sel_A <= Ins(9 downto 7);
            Reg_Sel_B <= Ins(6 downto 4);
            Add_Sub_En <= '1' ;
            
        when "01" =>  -- NEG
            Reg_Sel_B <= Ins(9 downto 7);
            Add_Sub_Sel <= '1';
            Add_Sub_En <= '1' ;
            
        when "11" =>  -- JZR
            Reg_En <= (others => '0');
            Reg_Sel_A <= Ins(9 downto 7);
            if Jmp_Reg_Chk = "0000" then
                Jmp_Flg <= '1';
            end if;
            
        when others =>
            null;
                         
    end case;
    
end process;

end behavioral ;