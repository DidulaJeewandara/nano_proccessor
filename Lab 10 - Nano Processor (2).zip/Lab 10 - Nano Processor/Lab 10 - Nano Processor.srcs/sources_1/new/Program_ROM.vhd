----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/11/2025 08:44:58 PM
-- Design Name: 
-- Module Name: Program_ROM - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.numeric_std.all; 

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Program_ROM is
    Port ( ROM_Sel : in STD_LOGIC_VECTOR (2 downto 0);
           Ins : out STD_LOGIC_VECTOR (11 downto 0));
end Program_ROM;

architecture Behavioral of Program_ROM is

---- Program that displays numbers by decrementing 10 by 1
type rom_type is array (0 to 7) of std_logic_vector(11 downto 0);

    constant PROGRAM_ROM : rom_type := (  
    
            0 => "101110000000",  -- MOVI R7, 0    (Initialize result register to 0)    -- Calculate the total between 1 to 3
            1 => "100100000001",  -- MOVI R2, 1    (Initialize counter to 1)
            2 => "100010000001",  -- MOVI R1, 1    (Set increment value to 1)
            3 => "001110100000",  -- ADD R7, R2    (Add current counter to sum in R7)
            4 => "000100010000",  -- ADD R2, R1    (Increment counter to 2)
            5 => "001110100000",  -- ADD R7, R2    (Add current counter to sum in R7)
            6 => "000100010000",  -- ADD R2, R1    (Increment counter to 3)
            7 => "001110100000"   -- ADD R7, R2    (Add current counter to sum in R7)

--            "100010000011", -- 0 -- MOVI R1, 3   
--            "100100000001", -- 1 -- MOVI R2, 1
--            "010100000000", -- 2 -- NEG R2
--            "001110010000", -- 3 -- ADD R7, R1
--            "000010100000", -- 4 -- ADD R1, R2
--            "110010000111", -- 5 -- JZR R1, 7 
--            "110000000011", -- 6 -- JZR R0, 3
--            "000000000000"  -- 7 -- END

--             "101110001010", -- 0 -- MOVI R7, 10      --    Numbers from 10 to 0
--             "100100000001", -- 1 -- MOVI R2, 1
--             "010100000000", -- 2 -- NEG R2
--             "001110100000", -- 3 -- ADD R7, R2
--             "111110000111", -- 4 -- JZR R7, 7
--             "110000000011", -- 5 -- JZR R0, 3
--             "111110000111", -- 6 -- JZR R1, 7
--             "110000000000" -- 7 -- END

        );
 
     
begin

Ins <= PROGRAM_ROM(to_integer(unsigned(ROM_Sel)));
    
end Behavioral;

