----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/11/2025 02:52:59 PM
-- Design Name: 
-- Module Name: Register_Bank - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;


-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Register_Bank is
    Port ( RB_En : in STD_LOGIC;     --enable the decoder
           Clk : in STD_LOGIC;
           Reset : in STD_LOGIC;
           R_En : in STD_LOGIC_VECTOR (2 downto 0);
           Input : in STD_LOGIC_VECTOR (3 downto 0);
           R_0 : out STD_LOGIC_VECTOR (3 downto 0);
           R_1 : out STD_LOGIC_VECTOR (3 downto 0);
           R_2 : out STD_LOGIC_VECTOR (3 downto 0);
           R_3 : out STD_LOGIC_VECTOR (3 downto 0);
           R_4 : out STD_LOGIC_VECTOR (3 downto 0);
           R_5 : out STD_LOGIC_VECTOR (3 downto 0);
           R_6 : out STD_LOGIC_VECTOR (3 downto 0);
           R_7 : out STD_LOGIC_VECTOR (3 downto 0));
end Register_Bank;

architecture Behavioral of Register_Bank is

component Register_4bit
    Port ( D : in STD_LOGIC_VECTOR (3 downto 0);
           Reset : in STD_LOGIC;
           En : in STD_LOGIC;
           Clk : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (3 downto 0));
end component;

component Decoder_3_8
    Port ( D : in STD_LOGIC_VECTOR (2 downto 0);
           EN : in STD_LOGIC;
           Q : out STD_LOGIC_VECTOR (7 downto 0));
end component;

signal R_Selector : STD_LOGIC_VECTOR(7 downto 0);
                   
begin

Decoder_3_8_0 : Decoder_3_8
        port map(
        En => RB_En ,
        D => R_En ,
        Q => R_Selector
        );
        
R_0 <= "0000" ;
    
REG_1: Register_4bit
        port map(
        D=>input,
        Reset=>Reset,
        En=>R_selector(1),
        Q=>R_1,
        Clk=>Clk
        );  
       
REG_2: Register_4bit
        port map(
        D=>input,
        Reset=>Reset,
        En=>R_selector(2),
        Q=>R_2,
        Clk=>Clk
        ); 
     
REG_3: Register_4bit
        port map(
        D=>input,
        Reset=>Reset,
        En=>R_selector(3),
        Q=>R_3,
        Clk=>Clk
        );          
           
REG_4: Register_4bit
        port map(
        D=>input,
        Reset=>Reset,
        En=>R_selector(4),
        Q=>R_4,
        Clk=>Clk
        );  
                           
REG_5: Register_4bit
        port map(
        D=>input,
        Reset=>Reset,
        En=>R_selector(5),
        Q=>R_5,
        Clk=>Clk
        );  

REG_6: Register_4bit
        port map(
        D=>input,
        Reset=>Reset,
        En=>R_selector(6),
        Q=>R_6,
        Clk=>Clk
        );   
        
REG_7: Register_4bit
        port map(
        D=>input,
        Reset=>Reset,
        En=>R_selector(7),
        Q=>R_7,
        Clk=>Clk
        );                                                                

end Behavioral;

