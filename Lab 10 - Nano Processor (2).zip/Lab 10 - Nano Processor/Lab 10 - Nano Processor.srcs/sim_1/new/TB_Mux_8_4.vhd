----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/16/2025 09:17:47 AM
-- Design Name: 
-- Module Name: TB_Mux_8_4 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Mux_8_4 is
--  Port ( );
end TB_Mux_8_4;

architecture Behavioral of TB_Mux_8_4 is

component Mux_8_4
port(I_0 : in STD_LOGIC_VECTOR (3 downto 0);
     I_1 : in STD_LOGIC_VECTOR (3 downto 0);
     I_2 : in STD_LOGIC_VECTOR (3 downto 0);
     I_3 : in STD_LOGIC_VECTOR (3 downto 0);
     I_4 : in STD_LOGIC_VECTOR (3 downto 0);
     I_5 : in STD_LOGIC_VECTOR (3 downto 0);
     I_6 : in STD_LOGIC_VECTOR (3 downto 0);
     I_7 : in STD_LOGIC_VECTOR (3 downto 0);
     Selector : in STD_LOGIC_VECTOR (2 downto 0);
     Q : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal I_0, I_1, I_2, I_3, I_4, I_5, I_6, I_7, Q : STD_LOGIC_VECTOR(3 downto 0);
Signal Selector : STD_LOGIC_VECTOR(2 downto 0);

begin
UUT: Mux_8_4
port map(
    I_0 => I_0,
    I_1 => I_1,
    I_2 => I_2,
    I_3 => I_3,
    I_4 => I_4,
    I_5 => I_5,
    I_6 => I_6,
    I_7 => I_7,
    Selector => Selector,
    Q => Q 
    );

-- Index Numbers of Team Members
        -- Gimhan M D C Y - 230201A - 111000001100111001
        -- Gunasekara H K B A - 230207X - 111000001100111111
        -- Jeewandara J D H - 230303M - 111000001110011111
        -- Navodya H H D - 230424J - 111000010000011000
        
process
begin
    I_0 <= "1001";
    I_1 <= "1010";
    I_2 <= "0011";
    I_3 <= "1111";
    I_4 <= "1110";
    I_5 <= "0101";
    I_6 <= "1000";
    I_7 <= "0111";
    
    Selector <= "000";
    wait for 100ns;

    Selector <= "001";
    wait for 100ns;
    
     Selector <= "010";
    wait for 100ns;   
    
    Selector <= "011";
    wait for 100ns;
    
    Selector <= "100";
    wait for 100ns;

    Selector <= "101";
    wait for 100ns;
    
    Selector <= "110";
    wait for 100ns;
    
    Selector <= "111";
    wait;
        
end process;

end Behavioral;

