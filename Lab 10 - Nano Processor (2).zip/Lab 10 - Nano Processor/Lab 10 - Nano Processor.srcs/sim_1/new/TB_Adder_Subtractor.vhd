----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/26/2025 03:23:37 PM
-- Design Name: 
-- Module Name: TB_Adder_Subtractor - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Adder_Subtractor is
--  Port ( );
end TB_Adder_Subtractor;

architecture Behavioral of TB_Adder_Subtractor is

component Adder_Subtractor is
    Port ( A : in STD_LOGIC_VECTOR (3 downto 0) ;
           B : in STD_LOGIC_VECTOR (3 downto 0) ;
           M : in STD_LOGIC ;
           En : in STD_LOGIC ;
           S : out STD_LOGIC_VECTOR (3 downto 0);
           Overflow : out STD_LOGIC;
           Zero : out STD_LOGIC);
end component ;

signal A, B, S : std_logic_vector (3 downto 0); 
signal M, En, Overflow, Zero : std_logic; 

begin
    UUT :Adder_Subtractor 
        port map( A => A,
                  B => B,
                  M => M,
                  En => En,
                  S => S,
                  Overflow => Overflow,
                  Zero => Zero );

-- Index Numbers of Team Members
          -- Gimhan M D C Y - 230201A - 11 1000 0011 0011 1001
          -- Gunasekara H K B A - 230207X - 11 1000 0011 0011 1111
          -- Jeewandara J D H - 230303M - 11 1000 0011 1001 1111
          -- Navodya H H D - 230424J - 11 1000 0100 0001 1000  
             
process begin
	
	En <= '1' ;
    -- 1 + 2
    A <= "1001";
    B <= "0011";
    M <= '0'; 
    wait for 100 ns;
    
    --(-1) - 3
    A <= "1111";
    B <= "0011";
    M <= '1';  
    wait for 100 ns;
    
    --(-7) + (-1)
    A <= "1001";
    B <= "1111";
    M <= '0';       
    wait for 100 ns;
    
    --(+1) - (-8)
    A <= "0001";
    B <= "1000";
    M <= '1';             
    wait for 100 ns;
   
   --(-7) + (-8)
    A <= "1001";
    B <= "1000";
    M <= '0';               
    wait for 100 ns;
    
    --(+3) - (+1)
    A <= "0011";
    B <= "0001";
    M <= '1';
    wait for 100 ns;
    
    --(+4) + (-8)
    A <= "0100";
    B <= "1000";
    M <= '0';                
    wait for 100 ns;

    --(-1) -(+4)
    A <= "1111";
    B <= "0100";
    M <= '1';                    
    wait ;              
     
end process;
    
end Behavioral;

