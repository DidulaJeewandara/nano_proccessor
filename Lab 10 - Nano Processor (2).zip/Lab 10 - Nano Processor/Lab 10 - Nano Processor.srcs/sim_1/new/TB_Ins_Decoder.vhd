----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/11/2025 08:28:53 PM
-- Design Name: 
-- Module Name: TB_Ins_Decoder - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Ins_Decoder is
--  Port ( );
end TB_Ins_Decoder;

architecture Behavioral of TB_Ins_Decoder is

component Ins_Decoder 
    Port ( Ins : in STD_LOGIC_VECTOR (11 downto 0);
           Jmp_Reg_Chk : in STD_LOGIC_VECTOR (3 downto 0);
           Load_Sel : out STD_LOGIC;
           Imd_Val : out STD_LOGIC_VECTOR (3 downto 0);
           Reg_En : out STD_LOGIC_VECTOR (2 downto 0);
           Reg_Sel_A : out STD_LOGIC_VECTOR (2 downto 0);
           Reg_Sel_B : out STD_LOGIC_VECTOR (2 downto 0);
           Add_Sub_Sel : out STD_LOGIC;
           Jmp_Flg : out STD_LOGIC;
           Adrs_to_Jmp : out STD_LOGIC_VECTOR (2 downto 0));
end component ;

signal Ins : STD_LOGIC_VECTOR (11 downto 0);
signal Jmp_Reg_Chk , Imd_Val : STD_LOGIC_VECTOR (3 downto 0);
signal Reg_En , Reg_Sel_A , Reg_Sel_B , Adrs_to_Jmp : STD_LOGIC_VECTOR (2 downto 0);
signal Load_Sel , Add_Sub_Sel , Jmp_Flg : STD_LOGIC;

begin

UUT : Ins_Decoder 
    port map(   Ins => Ins ,
                Jmp_Reg_Chk => Jmp_Reg_Chk ,
                Load_Sel => Load_Sel ,
                Imd_Val => Imd_Val ,
                Reg_En => Reg_En ,
                Reg_Sel_A => Reg_Sel_A ,
                Reg_Sel_B => Reg_Sel_B ,
                Add_Sub_Sel => Add_Sub_Sel ,
                Jmp_Flg => Jmp_Flg ,
                Adrs_to_Jmp => Adrs_to_Jmp );

-- Index Numbers of Team Members
        -- Gimhan M D C Y - 230201A - 111000001100111001
        -- Gunasekara H K B A - 230207X - 111000001100111111
        -- Jeewandara J D H - 230303M - 111000001110011111
        -- Navodya H H D - 230424J - 111000010000011000
            
process begin

        Jmp_Reg_Chk <= "0000";
        Ins <= "001100111001";
        wait for 100ns;
        
        Ins <= "001100111111";
        wait for 100ns;
        
        Ins <= "001110011111";
        wait for 100ns;

        Ins <= "010000011000";
        wait for 100ns;
        
        Jmp_Reg_Chk <= "1010";
        Ins <= "000110100000";
        wait for 100ns;
        
        Ins <= "110110000111";
        wait for 100ns;
        
        Ins <= "001100111111";
        wait for 100ns;
        
        Ins <= "110000000011";
        wait;
        
end process;

end Behavioral;

