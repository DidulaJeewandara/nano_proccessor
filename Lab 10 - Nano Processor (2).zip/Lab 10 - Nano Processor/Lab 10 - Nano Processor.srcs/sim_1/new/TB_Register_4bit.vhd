----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/15/2025 02:44:25 PM
-- Design Name: 
-- Module Name: TB_Register_4bit - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Register_4bit is
--  Port ( );
end TB_Register_4bit;

architecture Behavioral of TB_Register_4bit is

-- Component Declaration
component Register_4bit
    port (  D     : in  STD_LOGIC_VECTOR (3 downto 0);
            Reset : in  STD_LOGIC;
            En    : in  STD_LOGIC;
            Clk   : in  STD_LOGIC;
            Q     : out STD_LOGIC_VECTOR (3 downto 0)
            );
end component;

-- Testbench signals
signal D_tb     : STD_LOGIC_VECTOR (3 downto 0);
signal Reset_tb : STD_LOGIC;
signal En_tb    : STD_LOGIC;
signal Clk_tb   : STD_LOGIC;
signal Q_tb     : STD_LOGIC_VECTOR (3 downto 0);

begin

-- Instantiate the Unit Under Test (UUT)
uut : Register_4bit
    port map (
        D     => D_tb,
        Reset => Reset_tb,
        En    => En_tb,
        Clk   => Clk_tb,
        Q     => Q_tb
        );

    -- Clock process
clk_process : process
begin
    Clk_tb <= '0';
    wait for 10 ns;
    Clk_tb <= '1';
    wait for 10 ns;
end process;

-- Stimulus process
stim_proc : process
begin
    -- Initial values
    Reset_tb <= '1';
    En_tb <= '0';
    D_tb <= "0000";
    wait for 100ns;

    -- Release reset
    Reset_tb <= '0';
    wait for 100 ns;

    -- Enable and write data
    En_tb <= '1';
    D_tb <= "1010";
    wait for 100 ns;

    -- Change data again
    D_tb <= "1100";
    wait for 100 ns;

    D_tb <= "1111";
    wait for 100 ns;

    Reset_tb <= '0';
    wait for 100 ns;

end process;

end Behavioral;

