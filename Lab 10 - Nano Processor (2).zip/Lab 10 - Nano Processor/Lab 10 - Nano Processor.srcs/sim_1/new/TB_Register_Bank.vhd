----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/15/2025 11:50:29 AM
-- Design Name: 
-- Module Name: TB_Register_Bank - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Register_Bank is
--  Port ( );
end TB_Register_Bank;

architecture Behavioral of TB_Register_Bank is

component Register_Bank
         Port ( RB_En : in STD_LOGIC;      --enable the decoder
          Clk : in STD_LOGIC;
          Reset : in STD_LOGIC;
          R_En : in STD_LOGIC_VECTOR (2 downto 0);
          input : in STD_LOGIC_VECTOR (3 downto 0);
          R_0 : out STD_LOGIC_VECTOR (3 downto 0);
          R_1 : out STD_LOGIC_VECTOR (3 downto 0);
          R_2 : out STD_LOGIC_VECTOR (3 downto 0);
          R_3 : out STD_LOGIC_VECTOR (3 downto 0);
          R_4 : out STD_LOGIC_VECTOR (3 downto 0);
          R_5 : out STD_LOGIC_VECTOR (3 downto 0);
          R_6 : out STD_LOGIC_VECTOR (3 downto 0);
          R_7 : out STD_LOGIC_VECTOR (3 downto 0));
end component;

signal input :STD_LOGIC_VECTOR(3 downto 0);
signal Clk,Reset,RB_En : STD_LOGIC ;
signal R_En : STD_LOGIC_VECTOR(2 downto 0);
signal R_0,R_1,R_2,R_3,R_4,R_5,R_6,R_7 : STD_LOGIC_VECTOR(3 DOWNTO 0);


begin
UUT : register_bank
        Port map(
        RB_En=>RB_En,
        Clk=>Clk,
        Reset=>Reset,
        R_En=>R_En,
        input=>input,
        R_0=>R_0,
        R_1=>R_1,
        R_2=>R_2,
        R_3=>R_3,
        R_4=>R_4,
        R_5=>R_5,
        R_6=>R_6,
        R_7=>R_7);
        
process 
begin
    Reset <='1';
    wait for 100ns;
    Reset<='0';
    wait;
end process;   

Clk_process : process
    begin
        Clk<='0';
        wait for 10ns;
        
        clk<='1';
        wait for 10ns;
    end process;
        
-- Index Numbers of Team Members
            -- Gimhan M D C Y - 230201A - 111000001100111001
            -- Gunasekara H K B A - 230207X - 111000001100111111
            -- Jeewandara J D H - 230303M - 111000001110011111
            -- Navodya H H D - 230424J - 111000010000011000
            
process
begin
    RB_En<='1';
    
    R_En<="001";
    input<="1001";
    wait for 200ns;
    
    R_En<="010";
    input<="0011";
    wait for 100ns;
    
    R_En<="011";
    input<="1000";
    wait for 100ns;
    
    R_En<="100";
    input<="0011";
    wait for 100ns;
    
    R_En<="101";
    input<="1111";-- adding "f" hexa
    wait for 100ns;
    
    R_En<="110";
    input<="0010"; --adding "2"
    wait for 100ns;
    
    R_En<="111";
    input<="1100";--adding "c" in hexa
    wait;
end process;         

end Behavioral;

