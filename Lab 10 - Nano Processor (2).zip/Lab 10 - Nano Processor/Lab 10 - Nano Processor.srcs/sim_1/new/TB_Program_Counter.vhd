----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/15/2025 11:01:44 AM
-- Design Name: 
-- Module Name: TB_Program_Counter - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Program_Counter is
--  Port ( );
end TB_Program_Counter;

architecture Behavioral of TB_Program_Counter is

component Program_Counter
    Port(Clk : in STD_LOGIC;
         PC_In : in STD_LOGIC_VECTOR (2 downto 0);
         Reset : in STD_LOGIC;
         PC_Out : out STD_LOGIC_VECTOR (2 downto 0)); 
end component;

signal Clk : STD_LOGIC := '0';
signal Reset : STD_LOGIC;
signal PC_In, PC_Out : STD_LOGIC_VECTOR(2 downto 0);

begin
UUT : Program_Counter 
port map(
    Clk => Clk,
    PC_In => PC_In,
    Reset => Reset, 
    PC_Out => PC_Out 
    );

process 
    begin
        wait for 5ns;
        Clk <= NOT(Clk);
end process;
  
-- Index Numbers of Team Members
        -- Gimhan M D C Y - 230201A - 111000001100111001
        -- Gunasekara H K B A - 230207X - 111000001100111111
        -- Jeewandara J D H - 230303M - 111000001110011111
        -- Navodya H H D - 230424J - 111000010000011000
        
process 
    begin
  
    Reset <= '1';
    wait for 100ns;
    
    Reset <='0';
    PC_in <= "001";
    wait for 200ns;
    
    PC_in <= "111";
    wait for 200ns;
    
    PC_in <= "000";
    wait for 200ns;
    
    PC_in <= "100";
    wait for 200ns;
    
    Reset <= '1';
    PC_in <= "110";
    wait;
   
end process;

end Behavioral;
