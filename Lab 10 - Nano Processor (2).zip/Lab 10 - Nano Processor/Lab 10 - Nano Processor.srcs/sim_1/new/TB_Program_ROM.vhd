----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05/11/2025 08:53:52 PM
-- Design Name: 
-- Module Name: TB_Program_ROM - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TB_Program_ROM is
--  Port ( );
end TB_Program_ROM;

architecture Behavioral of TB_Program_ROM is

component Program_ROM
    Port (  ROM_Sel : in STD_LOGIC_VECTOR (2 downto 0);
            Ins :OUT STD_LOGIC_VECTOR (11 DOWNTO 0));
end component ;

signal ROM_Sel : STD_LOGIC_VECTOR(2 downto 0);
signal Ins : STD_LOGIC_VECTOR(11 downto 0);

begin

UUT : Program_ROM 
    port map(   ROM_Sel => ROM_Sel ,   
                Ins => Ins );
                
process begin

        ROM_Sel <= "000";
        wait for 100ns;
        
        ROM_Sel <= "001";
        wait for 100ns;
        
        ROM_Sel <= "010";
        wait for 100ns;
        
        ROM_Sel <= "011";
        wait for 100ns;
        
        ROM_Sel <= "100";
        wait for 100ns;
        
        ROM_Sel <= "101";
        wait for 100ns;
        
        ROM_Sel <= "110";
        wait for 100ns;
        
        ROM_Sel <= "111";
        wait;
        
end process;

end Behavioral;
